jQuery(document).ready(function () {
    // Carousel
	jQuery('.carousel').slick({
		arrows: false,
		dots: true,
		infinite: true,
		autoplay: true,
		slidesToShow: 3,
		slidesToScroll: 3,
		autoplaySpeed: 3000,
		responsive: [
			{
			  breakpoint: 992,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 2,
			  }
			},
			{
			  breakpoint: 768,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
		]
	});
	
	jQuery('.carousel1').slick({
		arrows: false,
		dots: true,
		infinite: true,
		autoplay: true,
		autoplaySpeed: 3000
	});
});